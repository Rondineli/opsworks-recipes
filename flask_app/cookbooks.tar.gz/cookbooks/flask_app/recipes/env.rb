#
# Cookbook:: flask_app
# Recipe:: default
#
# Copyright:: 2019, The Authors, All Rights Reserved.


packages_to_install = [
  'uwsgi', 'python3-minimal', 'python3-dev','python3-pip', 'nginx',
  'wget', 'vim'
]

packages_to_install.each do |pkg|
  log 'installing by pkg ' + pkg
  apt_package pkg do
    action :install
  end
end

bash "run_install" do
  user "root"
  cwd "/opt/aws_labs/app/flask/"
  code <<-EOH
    pip3 install -U pipenv
    pipenv install
  EOH
  action :run
end
