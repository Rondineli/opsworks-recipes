git 'aws-labs' do
  checkout_branch         "master"
  repository              "git@github.com:Rondineli/aws-labs.git"
  destination             "/opt/aws_labs"
end
